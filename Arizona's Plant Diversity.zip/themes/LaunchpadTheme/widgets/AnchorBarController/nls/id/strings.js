define({
  "_widgetLabel": "Pengontrol Anchor Bar",
  "_layout_default": "Tata letak default",
  "_layout_layout1": "Tata Letak 0",
  "more": "Widget lainnya"
});