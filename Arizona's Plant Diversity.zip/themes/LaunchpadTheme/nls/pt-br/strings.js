define({
  "_themeLabel": "Tema da Plataforma de Inicialização",
  "_layout_default": "Layout padrão",
  "_layout_right": "Layout à direita"
});