define({
  "_themeLabel": "Tema för startplatta",
  "_layout_default": "Standardlayout",
  "_layout_right": "Höger layout"
});