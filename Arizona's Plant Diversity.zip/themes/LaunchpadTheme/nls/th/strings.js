define({
  "_themeLabel": "ธีมลอนช์แพด",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_right": "รูปแบบที่เหมาะสม"
});