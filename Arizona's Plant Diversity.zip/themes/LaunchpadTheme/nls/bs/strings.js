define({
  "_themeLabel": "Tema prozora za pokretanje",
  "_layout_default": "Zadani izgled",
  "_layout_right": "Pravi izgled"
});