define({
  "_themeLabel": "快速啟動板主題",
  "_layout_default": "預設版面配置",
  "_layout_right": "右側版面配置"
});